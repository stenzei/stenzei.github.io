server <- function(input, output, session) {
  output$forecast_table <- callModule(tableTile, "forecast_table",
                                      reactive(input$city),
                                      reactive(input$dta_source),
                                      reactive(input$number_of_days),
                                      forecast_dta)
  output$forecast_chart <- callModule(chartTile, "forecast_chart", 
                                      reactive(input$city), 
                                      reactive(input$dta_source),
                                      reactive(input$number_of_days),
                                      forecast_dta)
  output$forecast_map <- callModule(mapTile, "forecast_map", 
                                    reactive(input$city), 
                                    reactive(input$dta_source),
                                    reactive(input$all_cities),
                                    forecast_dta)
 
   callModule(qualityTile, "md_temperature_chart", 
             reactive(input$dta_source2),
             forecast_dta, "MEAN_DIFF_TEMPERATURE")
  callModule(qualityTile, "md_rain_prob_chart", 
             reactive(input$dta_source2),
             forecast_dta, "MEAN_DIFF_RAIN_PROB")
  callModule(qualityTile, "md_wind_speed_chart", 
             reactive(input$dta_source2),
             forecast_dta, "MEAN_DIFF_WIND_SPEED")
  callModule(qualityTile, "md_rain_ammount_chart", 
             reactive(input$dta_source2),
             forecast_dta, "MEAN_DIFF_RAIN_AMMOUNT")
  
  callModule(historyTile, "hist_temperature_chart", 
             reactive(input$city3),
             reactive(input$date3),
             reactive(input$dta_source3),
             forecast_dta, "TEMPERATURE")
  callModule(historyTile, "hist_rain_prob_chart", 
             reactive(input$city3),
             reactive(input$date3),
             reactive(input$dta_source3),
             forecast_dta, "RAIN_PROB")
  callModule(historyTile, "hist_wind_speed_chart", 
             reactive(input$city3),
             reactive(input$date3),
             reactive(input$dta_source3),
             forecast_dta, "WIND_SPEED")
  callModule(historyTile, "hist_rain_ammount_chart", 
             reactive(input$city3),
             reactive(input$date3),
             reactive(input$dta_source3),
             forecast_dta, "RAIN_AMMOUNT")
}