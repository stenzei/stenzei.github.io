ui <- dashboardPage(
  dashboardHeader(title = "Meta Weather"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Forecast", tabName = "forecast_item", icon = icon("cloud")),
      menuItem("Forecast Quality", tabName = "quality_item", icon = icon("bar-chart")),
      menuItem("Forecast History", tabName = "history_item", icon = icon("area-chart")),
      menuItem("About", tabName = "about_item", icon = icon("info"))
    )
  ),
  dashboardBody(
    tabItems(
      tabItem(tabName = "forecast_item",
        fluidRow(
          column(width = 8, 
            box(width = NULL, tableTileUI("forecast_table")),
            box(width = NULL, chartTileUI("forecast_chart"))
          ),
          column(width = 4, 
            box(width = NULL, title = "Controls",
              selectizeInput("city", "Choose city:", 
                             choices = forecast_dta$get_all_cities(),
                             selected = c("Göttingen"),
                             multiple = TRUE,
                             options = list(hideSelected = TRUE,
                                            maxItems = 1)),
              checkboxInput("all_cities", "Show all available cities"),
              radioButtons("dta_source", "Choose data source:", 
                           choices = c("mean of all", forecast_dta$get_sources()), 
                           selected = "mean of all"),
              sliderInput("number_of_days", "Forecast horizon in days:", 
                          min = 1, max = 7, value = 5,step = 1, ticks = FALSE)
            ),
            box(width = NULL, mapTileUI("forecast_map"))
          )
        )
      ),
      tabItem(tabName = "quality_item",
        fluidRow(
          column(width = 5,
            box(width = NULL, title = "Mean Deviation from Temperature",
                qualityTileUI("md_temperature_chart")),
            box(width = NULL, title = "Mean Deviation from Rain Probability", 
                qualityTileUI("md_rain_prob_chart"))
          ),
          column(width = 5,
            box(width = NULL, title = "Mean Deviation from Wind Speed",
                qualityTileUI("md_wind_speed_chart")),
            box(width = NULL, title = "Mean Deviation from Rain Ammount", 
                qualityTileUI("md_rain_ammount_chart"))
          ),
          column(width = 2,
           box(width = NULL, title = "Controls",
             checkboxGroupInput("dta_source2", "Choose data source(s):", 
                                choices = forecast_dta$get_sources(), 
                                selected = forecast_dta$get_sources()))
          )
        )
      ),
      tabItem(tabName = "history_item",
        fluidRow(
          column(width = 5,
                 box(width = NULL, title = "Temperature",
                     historyTileUI("hist_temperature_chart")),
                 box(width = NULL, title = "Rain Probability", 
                     historyTileUI("hist_rain_prob_chart"))
          ),
          column(width = 5,
                 box(width = NULL, title = "Wind Speed",
                     historyTileUI("hist_wind_speed_chart")),
                 box(width = NULL, title = "Rain Ammount", 
                     historyTileUI("hist_rain_ammount_chart"))
          ),
          column(width = 2,
                 box(width = NULL, title = "Controls",
                     selectInput("city3", "Choose a city:", 
                                 forecast_dta$get_all_cities()),
                     dateInput("date3", "Select a Date:", 
                               value = lubridate::today(), 
                               format = "dd.mm.yyyy"),
                     checkboxGroupInput("dta_source3", "Choose data source(s):", 
                                        choices = forecast_dta$get_sources(), 
                                        selected = forecast_dta$get_sources()))
          )
        )
      ),
      tabItem(tabName = "history_item",
        fluidRow(
          "More content."
        )
      )
    )
  )
)
